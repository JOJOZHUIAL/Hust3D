import{I as t}from"./index-DjnQcg-L.js";const s=()=>t.get("/api/auth/captcha",{timeout:1e4}),c=a=>t.post("/api/auth/cas-login",a),p=()=>t.post("/api/auth/logout");export{c,s as g,p as l};
