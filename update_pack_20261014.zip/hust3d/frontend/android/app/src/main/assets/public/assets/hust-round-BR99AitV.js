const s="/assets/hust-round-DfnG_7mA.png";export{s as h};
