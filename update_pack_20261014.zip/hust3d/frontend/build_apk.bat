@echo off
cd /d %~dp0
python build_apk.py
pause
